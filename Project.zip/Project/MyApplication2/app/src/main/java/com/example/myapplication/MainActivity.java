package com.example.myapplication;

import java.util.ArrayList;
import java.util.Locale;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.memetix.mst.language.Language;
import com.memetix.mst.translate.Translate;
public class MainActivity  extends Activity implements OnInitListener {
    private TextToSpeech speak;
    private TextView text;
    private ImageButton mic;
    private static final int Input = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text = (TextView) findViewById(R.id.UserText);
        mic = (ImageButton) findViewById(R.id.btnSpeak);
        mic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startVoiceInput();
            }
        });

        speak = new TextToSpeech(this, this);
        ((Button) findViewById(R.id.bSpeak)).setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                speakOut(((TextView) findViewById(R.id.tvTranslatedText)).getText().toString());
            }
        });

        ((Button) findViewById(R.id.bTranslate)).setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub

                new bgStuff().execute();
            }

        });
    }

    class bgStuff extends AsyncTask<Void, Void, Void> {

        String translatedText = "";
        String text = ((EditText) findViewById(R.id.UserText)).getText().toString();

        @Override
        protected Void doInBackground(Void... params) {
            // TODO Auto-generated method stub
            try {

                translatedText = translate(text);
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                translatedText = e.toString();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            // TODO Auto-generated method stub
            ((TextView) findViewById(R.id.tvTranslatedText)).setText(translatedText);
            super.onPostExecute(result);
        }

    }

    public String translate(String text) throws Exception {

        Translate.setClientId("dfafb990-7803-4d42-8073-47c25fefec1b");
        Translate.setClientSecret("):/;^#)&4@>](H$eSe[@I=^");
       Translate.setHttpReferrer("https://api.cognitive.microsoft.com/sts/v1.0/issueToken?Subscription-Key=<cf3afca830424e4bb73af610b937d9a9>"); //Change this
        Translate.setKey("cf3afca830424e4bb73af610b937d9a9"); //change
        String translatedText = "";
       translatedText = Translate.execute(text, Language.FRENCH);
        return translatedText;
    }

    @Override
    public void onInit(int status) {
        // TODO Auto-generated method stub
        if (status == TextToSpeech.SUCCESS) {

            int result = speak.setLanguage(Locale.GERMAN);
            if (result == TextToSpeech.LANG_MISSING_DATA
                    || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.e("TTS", "This Language is not supported");
            } else {

            }
        } else {
            Log.e("TTS", "Initilization Failed!");
        }
    }

    private void speakOut(String text) {
        speak.speak(text, TextToSpeech.QUEUE_FLUSH, null);
    }

    private void startVoiceInput() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Hello, How can I help you?");
        try {
            startActivityForResult(intent, Input);
        } catch (ActivityNotFoundException a) {
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case Input: {
                if (resultCode == RESULT_OK && null != data) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    text.setText(result.get(0));
                }
                break;
            }
        }
    }
}
